package com.jy.announcement.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;

import com.jy.announcement.domain.Contents;
import com.jy.dao.getDao;

@Repository("contentDao")
public class ContentDao implements getDao{

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<Object> getList() {
		return sqlSession.selectList("getContent");
	}
	
	public List<Contents> getConetntView(Contents contents) {
		sqlSession.update("updateHit", contents);
		return sqlSession.selectList("getContent", contents);
	}
	
	public void writeContent(Contents contents) {
		sqlSession.insert("writeContent", contents);
	}
	
	public void updateContent(Contents contents) {
		sqlSession.update("updateContent",contents);
	}
	
	public void deleteContent(Contents contents) {
		sqlSession.delete("deleteContent", contents);
	}
}
