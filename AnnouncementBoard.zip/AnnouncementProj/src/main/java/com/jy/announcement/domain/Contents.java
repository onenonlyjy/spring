package com.jy.announcement.domain;

import java.sql.Timestamp;

public class Contents {

	private int id; //�Խù�ȣ
	private Timestamp regDate; //��ϳ�¥
	private Timestamp modiDate; //������¥
	private String contName; //������
	private String writer; //�ۼ���
	private String content; //�۳���
	private int hit;
	private boolean modified;
	private String process;
	
	public void Content() {
		this.hit = 0;
		this.modified = false;
	}
	
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public boolean isModified() {
		return modified;
	}
	public void setModified(boolean modified) {
		this.modified = modified;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Timestamp getRegDate() {
		return regDate;
	}
	public void setRegDate(Timestamp regDate) {
		this.regDate = regDate;
	}
	public Timestamp getModiDate() {
		return modiDate;
	}
	public void setModiDate(Timestamp modiDate) {
		this.modiDate = modiDate;
	}
	public String getContName() {
		return contName;
	}
	public void setContName(String contName) {
		this.contName = contName;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getHit() {
		return hit;
	}
	public void setHit() {
		hit+=1;
	}
	
	
}
