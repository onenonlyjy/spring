package com.jy.announcement.utils;
import org.apache.commons.lang3.StringUtils;

public class MybatisUtils {
	public static boolean isNotEmpty(final CharSequence cs) {
		return !StringUtils.isEmpty(cs);
	}
	public static boolean isNotEmpty(final Integer integer) {
		if(integer == null)
			return false;
		else
			return true;
	}
}
