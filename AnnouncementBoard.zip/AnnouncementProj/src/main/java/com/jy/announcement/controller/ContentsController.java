package com.jy.announcement.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jy.announcement.domain.Contents;
import com.jy.announcement.service.impl.ContentService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class ContentsController {
	
	@Autowired
	ContentService contentService;
	Contents contents = new Contents();
	
	@RequestMapping(value="/list")
	public String getContentList(Model model) {
		model.addAttribute("list",contentService.getContentList());
		return "list";
	
	}
	
	@RequestMapping(value="/view", method=RequestMethod.GET)
	public String getConetntView(HttpServletRequest req, Model model) {
		System.out.println("/view in ContentsController has accepted." + req.getParameter("req"));
		contents.setId(Integer.parseInt(req.getParameter("req")));
		contents.setHit();
		System.out.println("==============================="+contents.getId());
		model.addAttribute("view",contentService.getConetntView(contents));
		
		return "view";
	}
	
	@RequestMapping(value="/write")
	public String writeConetnt(HttpServletRequest req, Model model) {
		System.out.println("/write in ContentsController has accepted.");
		return complexWM(req, model);
		
	}
	
	@RequestMapping(value="/modify")
	public String complexWM(HttpServletRequest req, Model model) {
		System.out.println("/modify in ContentsController has accepted.");
		
		if(req.getParameter("process").equals("write")) {
			contents.setProcess(req.getParameter("process"));
			model.addAttribute("view",contents);
			contents.setContent(null); //VO�ʱ�ȭ
			contents.setContName(null); //VO�ʱ�ȭ (���ϸ� �ݺ��Ͽ� �ۼ��ϱ� ������ ���, ��õ contName�� content���� ȭ�鿡 �ö󰡰Ե�)
			return "complex";
		}
		else {
			contents.setId(Integer.parseInt(req.getParameter("id")));
			System.out.println("parameter test==========>"+req.getParameter("process"));
			contents=contentService.getConetntView(contents).get(0);
			contents.setProcess(req.getParameter("process"));
			System.out.println("=====================modify======>"+contentService.getConetntView(contents).get(0).getProcess());
			System.out.println("=====================modify======>"+contentService.getConetntView(contents).get(0).getContent());
			System.out.println("=====================modify======>"+contentService.getConetntView(contents).get(0).getContName());
			model.addAttribute("view",contents);
			return "complex";
		}
	}
	
	@RequestMapping(value="/multiProcess", method=RequestMethod.POST)
	public String multiProcess(HttpServletRequest req, Model model) {
		
		if(req.getParameter("isNew").equals("yes")) {
			contents.setContName((String)req.getParameter("contName"));
			contents.setContent((String)req.getParameter("content"));
			contentService.writeContent(contents);
			return "redirect:list";
		}
		else {
			contents.setId(Integer.parseInt(req.getParameter("id")));
			contents.setContName((String)req.getParameter("contName"));
			contents.setContent((String)req.getParameter("content"));
			contentService.updateContent(contents);
			contents.setModified(true);
			model.addAttribute("check",contents);
			return "complex";
		}
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String deleteContent(HttpServletRequest req) {
		contents.setId(Integer.parseInt(req.getParameter("id")));
		contentService.deleteContent(contents);
		return "redirect:list";
	}
	
/*	
	@RequestMapping(value="/write_process", method=RequestMethod.POST)
	public String writeProcess(HttpServletRequest req, Model model) {
		contents.setContName((String)req.getParameter("contName"));
		contents.setContent((String)req.getParameter("content"));
		contentService.writeContent(contents);
		
		model.addAttribute("models",contentService.getContentList());
		
		return "redirect:list";
	}
	
	@RequestMapping(value="/modify_process")
	public String modifyProcess(HttpServletRequest req, Model model) {
		contents.setId(Integer.parseInt(req.getParameter("id")));
		contents.setContName((String)req.getParameter("contName"));
		contents.setContent((String)req.getParameter("content"));
		contentService.updateContent(contents);
		contents.setModified(true);
		model.addAttribute("check",contents);
		return "complex";
	}
	*/
	/*@RequestMapping(value="/process", method=RequestMethod.POST)
	public String complexProcess(HttpServletRequest req, Model model) {
		if(req.getParameter("process").equals("write")) {
			contents.setProcess(1);
			contents.setContName((String)req.getParameter("contName"));
			contents.setContent((String)req.getParameter("content"));
			contentService.writeProcess(contents);
			model.addAttribute("models",contentService.getContentList());
		}
		return "complex";
	}
	
	@RequestMapping(value="/write_process", method=RequestMethod.POST)
	public String writeProcess(Model model) {
		contents.setContName((String)model.getParameter("contName"));
		contents.setContent((String)model.getParameter("content"));
		contentService.writeProcess(contents);
		model.addAttribute("models",contentService.getContentList());
		
		return "redirect:list";
	}
	
	@RequestMapping(value="/modify")
	public String complexWM(HttpServletRequest req, Model model) {
		System.out.println("/modify in ContentsController has accepted.");
		if(req.getParameter("process").equals("write")) {
			return 
		}
		
		else {
			contents.setId(Integer.parseInt(req.getParameter("id")));
		}
		
		model.addAttribute("view", contentService.getConetntView(contents));
		
		return "complex";
	}

	@RequestMapping(value="/modify_process")
	public String modifyProcess(HttpServletRequest req, Model modle) {
		contents.setId(Integer.parseInt(req.getParameter("id")));
		model.addAttribute("view", contentService.getConetntView(contents));
		return "modify";
	}*/
}
