package com.jy.announcement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jy.announcement.dao.impl.ContentDao;
import com.jy.announcement.domain.Contents;

@Service("contentService")
public class ContentService{
	
	@Autowired
	private ContentDao contentDao;
	
	/*
	public List<Contents> getContentsList() {
		
		List<Object> objectList = contentDao.getList();
		List<Contents> resultList = new ArrayList<Contents>();
		
		for(Object item : objectList) {
			resultList.add((Contents)item);
		}
		
		return resultList;
	
	}
	*/
	
	public List<Contents> getContentList() {
		return (List<Contents>)(Object)contentDao.getList();
	}
	
	public List<Contents> getConetntView(Contents contents) {
		return  contentDao.getConetntView(contents);
	}
	
	public void writeContent(Contents contents) {
		contentDao.writeContent(contents);
	}
	
	public void updateContent(Contents contents) {
		contentDao.updateContent(contents);
	}
	
	public void deleteContent (Contents contents) {
		contentDao.deleteContent(contents);
	}
}
